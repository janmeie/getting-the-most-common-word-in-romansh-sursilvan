#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author: Jana Meier

""" Converts a pdf to a txt. """

import glob
import os
from pdfminer.high_level import extract_text

input_path = '../data/La_Quotidiana_PDF'
file_list = glob.glob(os.path.join(input_path, '*.pdf'))
output_path = '../data/La_Quotidiana_txt'


number = 0
for file in file_list:
    number += 1
    file_name = 'la_quotidiana' + str(number) + '.txt'
    complete_name = os.path.join(output_path, file_name)
    with open(file, 'rb') as input, open(complete_name, 'w', encoding= 'utf-8') as output:
        text = extract_text(input)
        output.write(''.join(text))


