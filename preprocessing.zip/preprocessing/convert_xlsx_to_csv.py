#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author: Jana Meier

""" Converts xlsx to csv. """

import pandas as pd

read_file = pd.read_excel('../data/NVS-sco-PG_A-Z.xlsx')

read_file.to_csv('../data/NVS-sco-PG_A-Z.csv', index = None, header = True)
